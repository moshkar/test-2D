

package com.mycompany.coffeehutreport;


public class CoffeeHutReport {

    public static void main(String[] args) {
        
         // 1D arrays - as required by question
        String[] cities = {"Cape Town", "Port Elizabeth", "Pretoria"};
        String[] beverages = {"Coffee", "Tea", "Boba Tea"};

        // 2D array - sales data [cities][beverages]
        int[][] sales = {
            {500, 300, 125}, // Cape Town
            {450, 250, 100}, // Port Elizabeth
            {480, 175, 120} // Pretoria
        };

// Variables for total and city with most sales
        int[] totalSales = new int[3];
        int maxSales = 0;
        String cityWithMostSales = "";

        // Calculate total sales for each city
        for (int i = 0; i < 3; i++) {
            totalSales[i] = sales[i][0] + sales[i][1] + sales[i][2];

            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                cityWithMostSales = cities[i];
            }
        }

        // Display the report
        System.out.println("----------------------------------------------------------");
        System.out.println("COFFEE HUT BEVERAGE REPORT");
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-20s %-10s %-10s %-10s\n", "", beverages[0], beverages[1], beverages[2]);
        System.out.println();

        for (int i = 0; i < 3; i++) {
            System.out.printf("%-20s %-10d %-10d %-10d\n", cities[i], sales[i][0], sales[i][1], sales[i][2]);
        }

        System.out.println();
        System.out.println("----------------------------------------------------------");
        System.out.println("BEVERAGE SALES TOTALS FOR EACH CITY");
        System.out.println("----------------------------------------------------------");

        for (int i = 0; i < 3; i++) {
            System.out.println(cities[i] + "\t" + totalSales[i]);
        }

        System.out.println();
        System.out.println("CITY WITH THE MOST SALES: " + cityWithMostSales);
        System.out.println("----------------------------------------------------------");
    }
}
        
        
    


